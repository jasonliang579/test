package com.jieyangjiancai.zwj.data;

import java.util.ArrayList;

public class SwitchItem {
	public int id;
	public String name;
	public String productId;
	public ArrayList<SwitchItem> items = new ArrayList<SwitchItem>();
}
