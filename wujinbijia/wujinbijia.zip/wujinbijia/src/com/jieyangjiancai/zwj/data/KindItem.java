package com.jieyangjiancai.zwj.data;


public class KindItem {
	public String id;
	public String itemName;
}
