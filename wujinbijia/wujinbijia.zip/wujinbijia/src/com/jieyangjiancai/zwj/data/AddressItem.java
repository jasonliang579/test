package com.jieyangjiancai.zwj.data;

import java.util.ArrayList;

public class AddressItem { 
	public String id;
	public String name;
	public ArrayList<AddressItem> addressList = new ArrayList<AddressItem>();
}
