package com.jieyangjiancai.zwj.data;

import java.util.ArrayList;

public class KindItemList {
	public String code;
	public String id;
	public String name;
	public String version;
	public ArrayList<KindItem> kindItemList = new ArrayList<KindItem>();
}
