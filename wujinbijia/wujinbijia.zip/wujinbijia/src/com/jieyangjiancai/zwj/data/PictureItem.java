package com.jieyangjiancai.zwj.data;

public class PictureItem {
	public String path;
	public String thumb;
	public int picture_id;
}
