package com.jieyangjiancai.zwj.data;

import java.util.ArrayList;


public class StandardItem {
	public int cmRelId;
	public int id;
	public String name;
	public ArrayList<AreaItem> mListArea = new ArrayList<AreaItem>();
}
