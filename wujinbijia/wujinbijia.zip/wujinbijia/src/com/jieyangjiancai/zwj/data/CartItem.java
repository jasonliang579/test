package com.jieyangjiancai.zwj.data;


public class CartItem {
	public int amount;
	public String brandId;
	public String colorName;
	public String id;
	public double price;
	public String productId;
	public String productName;
	public String propertyNameArr;
	//public String arrProperty;
	//public String arrPropertyId;
}
