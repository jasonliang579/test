package com.jieyangjiancai.zwj.data;

public class SupplierItem {
	public String block_count;
	public String deal_count;
	public String supplier_id;
	public String supplier_name;
	public String supplier_phone;
	public String company_name;
	public String address;
	public String area_name;
	public String city_name;
	public String province_name;
}
