package com.jieyangjiancai.zwj.data;

public class PropertyItem {
	public String id;
	public String value;
}
