package com.jieyangjiancai.zwj.data;

public class BrandItem { //品牌
	public String code;
	public int id;
	public String name;
	public String recommendFlag;
	public String showFlag;
	public String status;
}
