package com.jieyangjiancai.zwj.data;

public class BrandPriceItem {
	public String brandCode;
	public String brandName;
	public double price;
}
