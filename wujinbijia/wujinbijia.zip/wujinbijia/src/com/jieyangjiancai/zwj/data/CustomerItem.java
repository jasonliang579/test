package com.jieyangjiancai.zwj.data;

public class CustomerItem {
	public String block_count;
	public String businesscard_id;
	public String deal_count;
	public String company_name;
	public String address;
	public String area_name;
	public String area_code;
	public String city_name;
	public String city_code;
	public String province_name;
	public String province_code;
	public String total_rebate;
	public String user_id;
	public String user_name;
	public String user_type;
	public String phone;
}
