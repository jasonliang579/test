package com.jieyangjiancai.zwj.data;

public class AreaItem { //截面积 
	public int cmcRelId;
	public int id;
	public String name;
}
