package com.jieyangjiancai.zwj.data;

import java.util.ArrayList;

public class MessageItem {
	public String message_content;
	public String message_id;
	public String create_time; 	
	public MessageItem reply_message; 
	public String user_company;
	public String user_id;
	public String user_name;
}
