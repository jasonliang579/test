package com.jieyangjiancai.zwj.data;

public class SwitchPriceItem {
	public String brandCode;
	public String classificationCode;
	public int id;
	public int kindId;
	public String modelCode;
	public String modeltypeCode;
	public double realPrice;
	public String type;
}
