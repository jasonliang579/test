package com.jieyangjiancai.zwj.data;

import java.util.ArrayList;


public class CmcRelItem { //分类
	public int id;
	public String name;
	public ArrayList<StandardItem> mListStandard = new ArrayList<StandardItem>();
}
