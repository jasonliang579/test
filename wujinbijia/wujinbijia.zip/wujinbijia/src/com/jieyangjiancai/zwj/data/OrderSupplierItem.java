package com.jieyangjiancai.zwj.data;

public class OrderSupplierItem extends MyPriceItem{

}
