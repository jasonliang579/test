package com.jieyangjiancai.zwj.data;


public class UserItem {
	public String user_name;
	public String province_name;
	public String city_name;
	public String area_name;
}
