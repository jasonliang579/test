package com.jieyangjiancai.zwj.network;

import android.content.Context;

public class WebViewRequest {
	
	/**
	 * 这些是跳activity
	 * 
	 * @param url
	 */
	public static void gotoWebView(Context context, String url, String token, String title) {

			
//		Intent intent = new Intent(context, WebViewActivity.class);
//		intent.putExtra("url", url);
//		intent.putExtra("token", token);
//		intent.putExtra("title", title);
//		context.startActivity(intent);
	}
}
